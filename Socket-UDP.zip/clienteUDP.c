// cliente
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

struct reg{
	int opc;
	int ID;
	int saldo;
	}registro,r;
	
//programa main	
int main(int argc, char **argv[])
{
	if(argc > 2)
	{
		/***** 1. definir variables *****/
		char *ip;
		int puerto;	
		ip = argv[1];
		puerto = atoi(argv[2]);
		
		int sockfd;
		struct sockaddr_in addr; //info address
		char buffer[1024];
		socklen_t addr_size;

		int opcionUsuario;
		
		//create datagram socket
		sockfd = socket(AF_INET, SOCK_DGRAM, 0);

		//datos de address
		memset(&addr, '\0', sizeof(addr));
	  	addr.sin_family = AF_INET;
	  	addr.sin_port = htons(puerto);
	  	addr.sin_addr.s_addr = inet_addr(ip);
		
		do{
			//MENU DE INTERFAZ DE USUARIO

			printf("----- SELECCIONA UNA OPCION -----\n");
			printf("1. Alta de cuenta\n");
			printf("2. Retiro de una cuenta\n");
			printf("3. Abono a cuenta\n");
			printf("0. Salir\n");
			printf("---------------------------------\n");
			printf("Opcion: ");
			scanf("%d", &opcionUsuario);

			registro.opc = opcionUsuario;
			
			switch(opcionUsuario)
			{
				//alta de cuenta
				case 1:
					int idnuevo, saldonuevo;
					system("clear");
					printf("Ingresa el nuevo ID de la cuenta: ");
					scanf("%d", &idnuevo);
					registro.ID = idnuevo;
					printf("Ingresa el saldo de la cuenta: ");
					scanf("%d", &saldonuevo);
					registro.saldo = saldonuevo;
					break;
				//retiro	
				case 2:
					int idcuenta, saldoretirar;
					system("clear");
					printf("Ingresa el ID de la cuenta a retirar: ");
					scanf("%d", &idcuenta);
					registro.ID = idcuenta;
					printf("Ingresa el monto a retirar: ");
					scanf("%d", &saldoretirar);
					registro.saldo = saldoretirar;
					break;
				//abono
				case 3:
					int idcuenta2, saldoabonar;
					system("clear");
					printf("Ingresa el ID de la cuenta a abonar: ");
					scanf("%d", &idcuenta2);
					registro.ID = idcuenta2;
					printf("Ingresa el monto a abonar: ");
					scanf("%d", &saldoabonar);
					registro.saldo = saldoabonar;
					break;
				//salir
				case 0:
					printf("----- Saliendo del sistema -----\n");
					exit(0);
				//default
				default:
					printf("No se reconoce la opcion\n");
					exit(0);
			}
				
	 		sendto(sockfd, &registro, sizeof(struct reg), 0, (struct sockaddr*)&addr, sizeof(addr));
				
			bzero(buffer, 1024);
	  		addr_size = sizeof(addr);
	  		recvfrom(sockfd, buffer, 1024, 0, (struct sockaddr*)&addr, &addr_size);
	  		printf("[+]Servidor responde: %s\n", buffer);
				
		 }while(opcionUsuario != 0);

		//close the descriptor
		close(sockfd);	
		
	}
	else{
		printf("No se ingresó el ip y puerto\n");
	}
  return(0);
}
