//librerias
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>

struct reg{
	int opc;
	int ID;
	int saldo;
	} registro2;
struct reg registros[10];

#define men2 "Datos Recibidos"

int nreg=0;

//funcion de busqueda
int buscarEnArreglo(struct reg registros[], int busqueda, int longitud){
	for(int x = 0; x<longitud; x++){
		if (registros[x].ID == busqueda) return x;
	}
	return -1;
}

//programa main
int main(int argc, char **argv){
	if(argc > 1){
		/******** 1. definir variables ********/
		int fd, fd2, longitud_cliente, puerto;
		puerto=atoi(argv[1]);
		FILE *texto;
		char *nombreArchivo = "registros.txt";
		char buf[1024];
		
		//dos estructuras sockaddr
		struct sockaddr_in server; //info del server
		struct sockaddr_in client; //info del client
		
		//configuracion del servidor
		server.sin_family = AF_INET; //TCP/IP
		server.sin_port = htons(puerto); //puerto
		server.sin_addr.s_addr = INADDR_ANY; //cualquier cliente se puede conectar
		bzero(&(server.sin_zero),8); //rellena con 0
		
		/******** 2. definir socket ********/
		if(( fd=socket(AF_INET,SOCK_STREAM,0) )<0){
			perror("Error de apertura de socket");
			exit(-1);
		}
		
		/******** 3. avisar al sist que se creo el socket ********/
		if(bind(fd,(struct sockaddr*)&server, sizeof(struct sockaddr))==-1){
			printf("Error en bind()\n");
			exit(-1);
		}
		
		/******** 4. establecer el socket en modo escucha ********/
		if(listen(fd,5) == -1){
			printf("Error en listen()\n");
			exit(-1);
		}
		
		/******** 5. aceptar conexiones ********/
		
			longitud_cliente = sizeof(struct sockaddr_in);
			//llamada a accept()
			if((fd2 = accept(fd,(struct sockaddr *)&client, &longitud_cliente))==-1) {
				printf("Error en accept()\n");
				exit(-1);
			}
		while(1){	
			read(fd2, &registro2, sizeof(struct reg));
			printf("**** Datos recibidos ****\n");
			printf("Opcion -> %d \n",registro2.opc);
			printf("ID -> %d \n",registro2.ID);	
			printf("Saldo -> %d \n",registro2.saldo);
			
			switch(registro2.opc)
     		{
			 	//Alta de cuenta
			 	case(1):
			 		if(registro2.ID < 0) break;
			 		int comp = buscarEnArreglo(registros, registro2.ID, nreg);
			 	        if(comp == -1 && registro2.saldo >= 0){
			 		    	registros[nreg].ID = registro2.ID;
			 		    	registros[nreg].saldo = registro2.saldo;
			 		    	nreg++;
			 		    	break; 
			 		}
			 		printf("Error --> Cuenta ya existente o saldo incorrecto\n");
			 		break;	            
			 	//Retiro
			   	case(2):
			   		int posicion = buscarEnArreglo(registros, registro2.ID, nreg);
			   		if (posicion != -1 && registro2.saldo <= registros[posicion].saldo && registro2.saldo > 0){
			   			registros[posicion].saldo = registros[posicion].saldo - registro2.saldo;
			   			break;	
			   		}
			   		printf("Error --> Cuenta no existente o fondos insuficientes\n");
			   		break;
			   	//Abono	
			   	case(3):
			   		int posicionA = buscarEnArreglo(registros, registro2.ID, nreg);
			   		if (posicion != -1 && registro2.saldo > 0){
			   			registros[posicionA].saldo = registros[posicionA].saldo + registro2.saldo;
			   			break;	
			   		}
			   		printf("Error --> Cuenta no existente o cantidad incorrecta\n");
			   		break;
			   	//salir
			   	case(0):
			   		exit(0);
			   	default:
			   		exit(1);
      		}
			
			if((texto = fopen(nombreArchivo,"w")) == NULL){
				printf("No se puede abrir archivo \n");
				return 0;
			}		
			for(int i = 0; i < nreg; i++){
				struct reg regActual = registros[i];
        		printf("ID: %d \tSaldo: %d \n",regActual.ID, regActual.saldo);
        		fprintf(texto, "ID: %d \tSaldo: %d \n",regActual.ID, regActual.saldo);
			}
	
			fclose(texto);
			
			if(write(fd2,men2,strlen(men2)+1)<0) perror("Servidor escribiendo el mensaje");
			printf("%s\n",men2);
						
		}
		close(fd2); //cierra el cliente
		close(fd); //cierra el server
	 
    }
	else{
		printf("No se ingreso el puerto\n");
	}
	
	return 0;
}
