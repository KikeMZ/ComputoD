//librerias
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

struct reg{
	int opc;
	int ID;
	int saldo;
	}registro,r;

//programa main
int main(int argc, char **argv[])
{
	if(argc > 2)
	{
		/***** 1. definir variables *****/
		char *ip;
		int fd, fd2, numbytes, puerto;
		char buf[100];
		puerto=atoi(argv[2]);
		ip=argv[1];
		
		struct hostent *he; //recibe info del nodo remoto
		struct sockaddr_in server; //info del server
		
		if((he=gethostbyname(ip))==NULL){
			printf("gethostbyname() error\n");
			exit(-1);
		}
		
		/***** 2. definir socket *****/
		if((fd=socket(AF_INET, SOCK_STREAM, 0))==-1){
			printf("socket() error\n");
			exit(-1);
		}
		
		//datos del server
		server.sin_family = AF_INET;
		server.sin_port = htons(puerto);
		server.sin_addr = *((struct in_addr *)he->h_addr);
		bzero(&(server.sin_zero),8);
		
		/***** 3. conectarse al server *****/
		if(connect(fd, (struct sockaddr *)&server, sizeof(struct sockaddr))==-1){
			printf("connect() error\n");
			exit(-1);
		}
		
		int opcionUsuario;
			do{
				//MENU DE INTERFAZ DE USUARIO

				printf("----- SELECCIONA UNA OPCION -----\n");
				printf("1. Alta de cuenta\n");
				printf("2. Retiro de una cuenta\n");
				printf("3. Abono a cuenta\n");
				printf("0. Salir\n");
				printf("---------------------------------\n");
				printf("Opcion: ");
				scanf("%d", &opcionUsuario);
				
				registro.opc= opcionUsuario;
				
				switch(opcionUsuario)
				{
					//alta de cuenta
					case 1:
						int idnuevo, saldonuevo;
						system("clear");
						printf("Ingresa el nuevo ID de la cuenta: ");
						scanf("%d", &idnuevo);
						registro.ID=idnuevo;
						printf("Ingresa el saldo de la cuenta: ");
						scanf("%d", &saldonuevo);
						registro.saldo = saldonuevo;
						break;
					//retiro	
					case 2:
						int idcuenta, saldoretirar;
						system("clear");
						printf("Ingresa el ID de la cuenta a retirar: ");
						scanf("%d", &idcuenta);
						registro.ID = idcuenta;
						printf("Ingresa el monto a retirar: ");
						scanf("%d", &saldoretirar);
						registro.saldo = saldoretirar;
						break;
					//abono
					case 3:
						int idcuenta2, saldoabonar;
						system("clear");
						printf("Ingresa el ID de la cuenta a abonar: ");
						scanf("%d", &idcuenta2);
						registro.ID = idcuenta2;
						printf("Ingresa el monto a abonar: ");
						scanf("%d", &saldoabonar);
						registro.saldo = saldoabonar;
						break;
					//salir
					case 0:
						printf("----- Saliendo del sistema -----\n");
						exit(0);
					//default
					default:
						printf("No se reconoce la opcion\n");
						exit(0);
				}
				
				write(fd,&registro,sizeof(struct reg));	
							
			}while(opcionUsuario != 0); 
					
		if(read(fd,buf,1024)<0) perror("Cliente leyendo mensaje\n");
		printf("%s\n",buf);
		
		close(fd);
	}
	
	else{
		printf("No se ingreso el ip y puerto\n");
	}
}
